# Plant Nanny
This is a project that uses various sensors/instruments to automate and monitor
plant-care tasks.

This project alerts person(s) via email for important alerts, progress updates, 
and other various information regarding the plant or the system.
